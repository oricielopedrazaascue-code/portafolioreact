# Portafolio React

Portafolio web desarrollado con React, TypeScript, Vite, React Hook Form y React Hot Toast.

## Ejecutar localmente

```bash
npm install
npm run dev
```

## Publicar en GitHub Pages

1. Sube este proyecto a un repositorio de GitHub.
2. Usa la rama `main`.
3. Ve a **Settings → Pages** y selecciona **GitHub Actions** como fuente.
4. Haz un push a `main`; el workflow de `.github/workflows/deploy.yml` construirá y publicará el sitio.
